class Employee1{
int id;
String name,department;
double baseSalary;
Employee1(int id,String name,double baseSalary,String department){
this.id=id;
this.name=name;
this.baseSalary=baseSalary;
this.department=department;
}
class SalaryBreakup{
double hra,da,pf,tax,netPay;
void computeBreakup(){
hra=baseSalary*0.20;
da=baseSalary*0.10;
pf=baseSalary*0.12;
double grossSalary=baseSalary+hra+da;
tax= grossSalary*0.05;
netPay=grossSalary-pf-tax;
}
void printBreakup(){
double grossSalary=baseSalary+hra+da;
System.out.println("HRA : "+hra);
System.out.println("DA : "+da);
System.out.println("Gross Salary : "+grossSalary);
System.out.println("PF : "+pf);
System.out.println("TAX : "+tax);
System.out.println("Net Salary : "+netPay);
}
}
void generateSlip(){
	System.out.println("SALARY SLIP");
displayEmployeeDetails();
SalaryBreakup sb=new SalaryBreakup();
sb.computeBreakup();
sb.printBreakup();
}

void displayEmployeeDetails(){
System.out.println("Employee Id : "+id);
System.out.println("Employee Name : "+name);
System.out.println("Department : "+department);
System.out.println("Basic Salary : "+baseSalary);
}
double calculateSalary(){
SalaryBreakup s=new SalaryBreakup();
s.computeBreakup();
System.out.println("SALARY SLIP");
displayEmployeeDetails();
s.printBreakup();
return s.netPay;
}
}
public class Employee{
public static void main(String args[]){
Employee1[] emp=new Employee1[2];
emp[0]=new Employee1(101,"Nitish",50000,"CSE");
emp[1]=new Employee1(102,"Charan",60000,"IT");

for(int i=0;i<emp.length;i++){
emp[i].generateSlip();
System.out.println();
}
}
}
