class Add{
int a,b;
int sum(){
return a+b;
}
public static void main(String args[]){
Add a1=new Add();
a1.a=200;
a1.b=300;
System.out.println("Sum is " +a1.sum());
}
}