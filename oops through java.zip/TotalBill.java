import java.util.*;
class Vehicle{
int VehicleNo;
String brand;
double baseFare;
Vehicle(int VehicleNo,String brand,double baseFare){
this.VehicleNo=VehicleNo;
this.brand=brand;
this.baseFare=baseFare;
}
double calculateFare(int days){
return baseFare*days;
}
void displayBill(int days){
System.out.println("Vehicle No: "+VehicleNo);
System.out.println("Days: "+days);
System.out.println("Total Fare : "+calculateFare(days));
}
}
class Car extends Vehicle{
int noOfSeats;
boolean acAvailable;
Car(int VehicleNo,String brand,double baseFare,int noOfSeats,boolean acAvailable){
super(VehicleNo,brand,baseFare);
this.noOfSeats=noOfSeats;
this.acAvailable=acAvailable;
}
double calculateFare(int days){
return (baseFare+500)*days;
}
void displayBill(int days){
System.out.println("---CAR BILL---");
super.displayBill(days);
System.out.println("Seats : "+noOfSeats);
System.out.println("AC Available : "+acAvailable);
}
}
class Bike extends Vehicle{
boolean helmetRequired;
boolean geared;
Bike(int VehicleNo,String brand, double baseFare,boolean helmetRequired,boolean geared){
	super(VehicleNo,brand,baseFare);
this.helmetRequired=helmetRequired;
this.geared=geared;
}
double calculateFare(int days){
return (baseFare+200)*days;
}
void displayBill(int days){
System.out.println("---BIKE BILL---");
super.displayBill(days);
System.out.println("Helmet Required : "+helmetRequired);
System.out.println("Geared : "+geared);
}
}
class SUV extends Vehicle{
boolean fourWheelDrive;
String luxuryLevel;
SUV(int VehicleNo,String brand, double baseFare,boolean fourWheelDrive,String luxuryLevel){
	super(VehicleNo,brand,baseFare);
this.fourWheelDrive=fourWheelDrive;
this.luxuryLevel=luxuryLevel;
}
double calculateFare(int days){
return (baseFare+1000)*days;
}
void displayBill(int days){
System.out.println("---SUV BILL---");
super.displayBill(days);
System.out.println("4 wheel drive : "+fourWheelDrive);
System.out.println("Luxury Level : "+luxuryLevel);
}
}
class TotalBill{
public static void main(String[] args){
Car c=new Car(101,"Toyota",1500,5,true);
Bike b=new Bike(102,"Honda",800,true,true);
SUV s=new SUV(103,"Mahindra",2500,true,"High");
int days=3;
c.displayBill(days);
b.displayBill(days);
s.displayBill(days);
}
}