class P{
static int x=10;
int y=20;
void display(){
system.out.println("value of y is ",+y);
}
public static void main(string args[]){
system.out.println("value of x is ",+X);
A.a1=new A();
a1.y=100;
a1.display();
A.a2=new A();
a2.y=400;
a2.display();
}
}