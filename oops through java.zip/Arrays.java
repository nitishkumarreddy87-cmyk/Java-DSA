import java.util.Scanner;
class Book{
String title,author,publisher,isbn;
int year;
double price;
Book(){
title="";
author="";
publisher="";
year=0;
isbn="";
price=0.0;
}
Book(String t,String a,String p,int y,String i,double pr){
title=t;
author=a;
publisher=p;
year=y;
isbn=i;
price=pr;
}

void displayDetails(){
System.out.println("Book details :");
System.out.println("Title = "+title);
System.out.println("Author = "+author);
System.out.println("Publisher = "+publisher);
System.out.println("Year = "+year);
System.out.println("ISBN = "+isbn);
System.out.println("Price= "+price);
}
boolean matches(String keyword){
return title.equalsIgnoreCase(keyword)||author.equalsIgnoreCase(keyword);
}
void applyDiscount(double percentage){
price=price-(price*(percentage/100));
}
}
public class Arrays{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);

Book b=new Book("Java","James","Sun microsystems",1995,"111",240.0);
b.displayDetails();
System.out.println("enter title/author :");
String key=sc.next();
if(b.matches(key))
	System.out.println("found");
	else
		System.out.println("not found");
	
	System.out.println("enter discount : ");
	double per=sc.nextInt();
	b.applyDiscount(per);
	
	System.out.println("After discount : ");
	b.displayDetails();
	sc.close();
	
}
}