import java.util.Scanner;
class BankAccount{
String accountHolder;
int accountNumber;
double balance;
String accountType;
BankAccount(String name,int accNo,double bal,String type){
accountHolder=name;
accountNumber=accNo;
balance=bal;
accountType=type;
}
void deposit(double amount){
balance=balance+amount;
System.out.println("Amount Deposited : "+amount);
}
void withdraw(double amount){
if(amount>balance){
System.out.println("Insufficient Funds!");
}
else{
balance=balance-amount;
System.out.println("Amount withdrawn : "+amount);
  }
}
void checkBalance(){
System.out.println("Current Balance : "+balance);
}
double CalculateInterest(float rate){
return (balance*rate)/100;
}
void display(){
System.out.println("Name : "+accountHolder);
System.out.println("Account Number : "+accountNumber);
System.out.println("Type : "+accountType);
System.out.println("Balance : "+balance);
    }
}
public class Account {
public static void main(String args[]){
	Scanner sc= new Scanner(System.in);
	BankAccount[] acc = new BankAccount[2];
	acc[0]=new BankAccount("Nitish",101,3000,"Saving");
	acc[1]=new BankAccount("Naseeruddin",102,5000,"Current");
	int choice;
	do{
		System.out.println("Bank menu : ");
		System.out.println("1.Display Accounts");
		System.out.println("2.Deposit");
		System.out.println("3. Withdraw");
		System.out.println("4.Check Balance");
		System.out.println("5.Calculate Interest ");
		System.out.println("6.Exit");
		System.out.println("Enter Choice");
		choice=sc.nextInt();
		int accNo;
		double amount,interest;
		float rate;
		switch(choice){
			case 1: for(int i=0;i<acc.length;i++){
             acc[i].display();
			}
			break;
			case 2: System.out.println("Enter Account no");
			accNo=sc.nextInt();
			System.out.print("Enter Amount :");
			amount=sc.nextDouble();
			for(int i=0;i<acc.length;i++){
				if(acc[i].accountNumber==accNo)
					acc[i].deposit(amount);
			}
			break;
			case 3:System.out.print("Enter account number");
			accNo=sc.nextInt();
			System.out.println("enter amount");
			amount=sc.nextDouble();
			for(int i=0;i<acc.length;i++){
				if(acc[i].accountNumber==accNo){
					acc[i].withdraw(amount);
				}
			}
			break;
			case 4:
			System.out.println("enter acc no");
			accNo=sc.nextInt();
			for(int i=0;i<acc.length;i++){
				if(acc[i].accountNumber==accNo){
					acc[i].checkBalance();
				}
			}
			break;
			case 5:
			System.out.print("enter Acc No");
			accNo=sc.nextInt();
			System.out.print("enter interest rate");
			rate=sc.nextFloat();
			for(int i=0;i<acc.length;i++){
			if(acc[i].accountNumber==accNo){
			 interest=acc[i].CalculateInterest(rate);
		System.out.println("Interest : "+interest);
			}
			}
			break;
			case 6:System.out.println("Thank You!");
			break;
			default:System.out.println("Invalid");
		}
	}while(choice!=6);
	sc.close();
}
}
		