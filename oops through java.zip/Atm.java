import java.util.Scanner;
class ATMpinchecker{
String username;
String pinStored;
ATMpinchecker(String username,String pinStored){
this.username=username;
this.pinStored=pinStored;
}
boolean verifyPIN(String eneteredPIN){
return pinStored.equals(eneteredPIN);
}
void authenticate(){
Scanner sc=new Scanner(System.in);
int attempts=0;
while(attempts<3){
System.out.println("enter PIN :");
String enteredPIN=sc.nextLine();
attempts++;
if(verifyPIN(enteredPIN)){
System.out.println("PIN ENTERED CORRECT");
return;
}
else{
System.out.println("INCORRECT PIN");
if(attempts<3){
System.out.println("Attempts Remaining : "+(3-attempts));
}
System.out.println("ACCOUNT LOCKED");
}
}
}
}
 class Atm{
public static void main(String []args){
ATMpinchecker u=new ATMpinchecker("Rahul","1234");
System.out.println("Welcome "+u.username);
u.authenticate();
}
}