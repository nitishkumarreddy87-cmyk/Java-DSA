import java.util.*;
class K{
public static int fact(int n){
	if(n==0)
		return 1;
	
	return fact(n-1)*n;
}
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter a number for factorial");
int n = sc.nextInt();
System.out.println("The Factorial of "+n+" is "+fact(n));
}
}