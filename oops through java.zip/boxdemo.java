class box{
double w;
double h;
double d;
}
public class boxdemo{
public static void main(String[] args){
box mybox1=new box();
box mybox2=new box();
double vol;
mybox1.w=10;
mybox1.h=20;
mybox1.d=15;
mybox2.w=3;
mybox2.h=6;
mybox2.d=9;
System.out.println("box 1 vol is:"+mybox1.w*mybox1.h*mybox1.d);
System.out.println("box 2 vol is:"+mybox2.w*mybox2.h*mybox2.d);
}
}