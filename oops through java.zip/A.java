class A{
public static void main(String args[]){
P obj=new P();
obj.display();
}
}
class P{
int x=10;
void display(){
System.out.println("the value is "+10);
}
}



