package CalcAdvanced;
public class Advanced_Calc{
public double power(double a,double b){
return Math.pow(a,b);
}
public double sqrt(double a){
if(a<0){
System.out.println("Error:Negative");
return 0;
}
return Math.sqrt(a);
}
public double log(double a){
if(a<=0){
System.out.println("Error:log Undefined");
return 0;
}
return Math.log(a);
}
}
