import java.util.Scanner;
import Calcbasic.BasicCalc;
import CalcAdvanced.Advanced_Calc;
import printDisplay.Display;
public class Multi_package{
public static void main(String[] args){
Scanner sc =  new Scanner(System.in);
BasicCalc bc = new BasicCalc();
Advanced_Calc ac = new Advanced_Calc();
Display d = new Display();
int choice;
do{
System.out.println("--Scientific Calculator--");
System.out.println("1.Add");
System.out.println("2.subtract");
System.out.println("3.multiply");
System.out.println("4.divide");
System.out.println("5.power");
System.out.println("6.Square root");
System.out.println("7.Log");
System.out.println("8.EXIT");
System.out.println("Enter choice : ");
choice=sc.nextInt();
double a,b,res=0;
switch(choice){
case 1: System.out.println("enter two numbers: ");
a=sc.nextDouble();
b=sc.nextDouble();
res=bc.add(a,b);
d.Showresult(res);
break;
case 2: System.out.println("enter two numbers: ");
a=sc.nextDouble();
b=sc.nextDouble();
res=bc.subtract(a,b);
d.Showresult(res);
break;
case 3: System.out.println("enter two numbers: ");
a=sc.nextDouble();
b=sc.nextDouble();
res=bc.multiply(a,b);
d.Showresult(res);
break;
case 4: System.out.println("enter two numbers: ");
a=sc.nextDouble();
b=sc.nextDouble();
res=bc.add(a,b);
d.Showresult(res);
break;
case 5: System.out.println("enter base and exponent: ");
a=sc.nextDouble();
b=sc.nextDouble();
res=ac.power(a,b);
d.Showresult(res);
break;
case 6: System.out.println("enter number: ");
a=sc.nextDouble();
res=ac.sqrt(a);
d.Showresult(res);
break;
case 7: System.out.println("enter number: ");
a=sc.nextDouble();
res=ac.log(a);
d.Showresult(res);
break;
case 8: System.out.print("EXITING....");
break;
default:System.out.print("Invalid Choice");
}
}while(choice!=8);
sc.close();
}
}