package printDisplay;
public class Display{
public void Showresult(double res){
System.out.print("Result : "+res);
}
}