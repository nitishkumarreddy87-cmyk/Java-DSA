abstract class MediaFile{
String fileName;
double duration,fileSize;
MediaFile(String fileName,double duration,double fileSize){
this.fileName=fileName;
this.duration=duration;
this.fileSize=fileSize;
}
abstract void play();
abstract void pause();
abstract void stop();
}
class AudioFile extends MediaFile{
AudioFile(String fileName,double duration,double fileSize){
super(fileName,duration,fileSize);
}
void play(){
System.out.println("Playing audio file : "+fileName);
}
void pause(){
System.out.println("Pausing audio file : "+fileName);
}
void stop(){
System.out.println("Stopping audio file : "+fileName);
}
}class VideoFile extends MediaFile{
VideoFile(String fileName,double duration,double fileSize){
super(fileName,duration,fileSize);
}
void play(){
System.out.println("Playing Video file : "+fileName);
}
void pause(){
System.out.println("Pausing Video file : "+fileName);
}
void stop(){
System.out.println("Stopping video file : "+fileName);
}
}
class LiveStream extends MediaFile{
LiveStream(String fileName,double duration,double fileSize){
super(fileName,duration,fileSize);
}
void play(){
System.out.println("Streaming Live : "+fileName);
}
void pause(){
System.out.println("Live Stream paused : "+fileName);
}
void stop(){
System.out.println("Live Stream stopped : "+fileName);
}
}
public class MediaPlayer{
public static void main(String[] args){
MediaFile m;
m=new AudioFile("Song mp3",3.5,5);
m.play();
m.pause();
m.stop();
m=new VideoFile("Movie mp4",120,700);
m.play();
m.pause();
m.stop();
m=new AudioFile("Live News",0,0);
m.play();
m.pause();
m.stop();
}
}
