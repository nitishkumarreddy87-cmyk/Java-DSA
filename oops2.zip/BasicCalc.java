package Calcbasic;
public class BasicCalc{
public double add(double a,double b){
return a+b;
}
public double subtract(double a ,double b){
return a-b;
}
public double multiply(double a,double b){
return a*b;
}
public double divide(double a,double b){
if(b==0){
System.out.println("Error: Division By Zero");
return 0;
}
return a/b;
}
}